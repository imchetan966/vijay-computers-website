from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def HOME():
    return render_template("Home.html")
    #return "<p>CHETAN!</p>"


@app.route("/Product")
def Product():
    return render_template("Product.html")


@app.route("/Services")
def Serviecs():
    return render_template("Services.html")

@app.route("/About")
def About():
    return render_template("About.html")

@app.route("/Contact")
def Contact():
    return render_template("Contact.html")


if __name__=="__main__":
    app.run(debug=True)